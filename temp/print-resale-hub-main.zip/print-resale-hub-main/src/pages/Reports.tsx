import { useState, useMemo } from 'react';
import { useData } from '@/contexts/DataContext';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/ui/page-header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { FileDown, FileSpreadsheet, Filter } from 'lucide-react';
import { StatusBadge } from '@/components/ui/status-badge';
import { generateReportPDF } from '@/lib/pdf-generator';
import { exportToExcel } from '@/lib/excel-generator';
import { toast } from '@/hooks/use-toast';

type ReportType = 'orders' | 'quotes' | 'financial' | 'profit';

export default function Reports() {
  const { orders, quotes, transactions, company } = useData();
  const [reportType, setReportType] = useState<ReportType>('orders');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filteredData = useMemo(() => {
    const start = startDate ? new Date(startDate) : null;
    const end = endDate ? new Date(endDate) : null;

    const filterByDate = <T extends { createdAt?: Date; date?: Date }>(items: T[]) => {
      return items.filter(item => {
        const itemDate = new Date(item.createdAt || item.date || new Date());
        if (start && itemDate < start) return false;
        if (end && itemDate > end) return false;
        return true;
      });
    };

    switch (reportType) {
      case 'orders':
        return filterByDate(orders);
      case 'quotes':
        return filterByDate(quotes);
      case 'financial':
        return filterByDate(transactions);
      case 'profit':
        const filteredTransactions = filterByDate(transactions);
        const income = filteredTransactions
          .filter(t => t.type === 'income')
          .reduce((acc, t) => acc + t.amount, 0);
        const expenses = filteredTransactions
          .filter(t => t.type === 'expense')
          .reduce((acc, t) => acc + t.amount, 0);
        return { income, expenses, profit: income - expenses, transactions: filteredTransactions };
      default:
        return [];
    }
  }, [reportType, startDate, endDate, orders, quotes, transactions]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const handleExportPDF = () => {
    generateReportPDF(reportType, filteredData, company, { startDate, endDate });
    toast({ title: 'PDF gerado com sucesso' });
  };

  const handleExportExcel = () => {
    exportToExcel(reportType, filteredData, { startDate, endDate });
    toast({ title: 'Excel gerado com sucesso' });
  };

  return (
    <MainLayout>
      <PageHeader
        title="Relatórios"
        description="Gere relatórios detalhados do seu negócio"
      />

      {/* Filters */}
      <div className="form-section mb-8 animate-fade-in">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-5 w-5 text-muted-foreground" />
          <h3 className="font-display text-lg font-semibold">Filtros</h3>
        </div>
        <div className="grid gap-4 sm:grid-cols-4">
          <div className="space-y-2">
            <Label>Tipo de Relatório</Label>
            <Select value={reportType} onValueChange={(v: ReportType) => setReportType(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="orders">Pedidos</SelectItem>
                <SelectItem value="quotes">Orçamentos</SelectItem>
                <SelectItem value="financial">Despesas e Receitas</SelectItem>
                <SelectItem value="profit">Lucro</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Data Inicial</Label>
            <Input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label>Data Final</Label>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>
          <div className="flex items-end gap-2">
            <Button onClick={handleExportPDF} variant="outline">
              <FileDown className="mr-2 h-4 w-4" />
              PDF
            </Button>
            <Button onClick={handleExportExcel} variant="outline">
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Excel
            </Button>
          </div>
        </div>
      </div>

      {/* Report Content */}
      {reportType === 'profit' && typeof filteredData === 'object' && 'profit' in filteredData ? (
        <div className="space-y-6 animate-slide-up">
          <div className="grid gap-4 sm:grid-cols-3">
            <Card>
              <CardHeader>
                <CardDescription>Receitas</CardDescription>
                <CardTitle className="text-success">{formatCurrency(filteredData.income)}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <CardDescription>Despesas</CardDescription>
                <CardTitle className="text-destructive">{formatCurrency(filteredData.expenses)}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <CardDescription>Lucro</CardDescription>
                <CardTitle className={filteredData.profit >= 0 ? 'text-success' : 'text-destructive'}>
                  {formatCurrency(filteredData.profit)}
                </CardTitle>
              </CardHeader>
            </Card>
          </div>
        </div>
      ) : reportType === 'orders' && Array.isArray(filteredData) ? (
        <div className="data-table animate-slide-up">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Número</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                    Nenhum pedido encontrado
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map((order: any) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">{order.number}</TableCell>
                    <TableCell>{order.clientName}</TableCell>
                    <TableCell>{formatDate(order.createdAt)}</TableCell>
                    <TableCell>
                      <StatusBadge status={order.status} />
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(order.total)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
          {filteredData.length > 0 && (
            <div className="p-4 border-t border-border">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">{filteredData.length} pedido(s)</span>
                <span className="font-semibold">
                  Total: {formatCurrency(filteredData.reduce((acc: number, o: any) => acc + o.total, 0))}
                </span>
              </div>
            </div>
          )}
        </div>
      ) : reportType === 'quotes' && Array.isArray(filteredData) ? (
        <div className="data-table animate-slide-up">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Número</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Validade</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                    Nenhum orçamento encontrado
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map((quote: any) => (
                  <TableRow key={quote.id}>
                    <TableCell className="font-medium">{quote.number}</TableCell>
                    <TableCell>{quote.clientName}</TableCell>
                    <TableCell>{formatDate(quote.createdAt)}</TableCell>
                    <TableCell>{formatDate(quote.validUntil)}</TableCell>
                    <TableCell>
                      <StatusBadge status={quote.status} />
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(quote.total)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      ) : reportType === 'financial' && Array.isArray(filteredData) ? (
        <div className="data-table animate-slide-up">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tipo</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Data</TableHead>
                <TableHead className="text-right">Valor</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                    Nenhuma transação encontrada
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map((transaction: any) => (
                  <TableRow key={transaction.id}>
                    <TableCell>
                      <span className={`badge-status ${transaction.type === 'income' ? 'badge-completed' : 'badge-cancelled'}`}>
                        {transaction.type === 'income' ? 'Receita' : 'Despesa'}
                      </span>
                    </TableCell>
                    <TableCell>{transaction.category}</TableCell>
                    <TableCell>{transaction.description}</TableCell>
                    <TableCell>{formatDate(transaction.date)}</TableCell>
                    <TableCell className={`text-right font-medium ${transaction.type === 'income' ? 'text-success' : 'text-destructive'}`}>
                      {transaction.type === 'income' ? '+' : '-'}{formatCurrency(transaction.amount)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      ) : null}
    </MainLayout>
  );
}
