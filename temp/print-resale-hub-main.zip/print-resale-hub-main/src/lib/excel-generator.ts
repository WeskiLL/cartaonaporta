import * as XLSX from 'xlsx';

const formatDate = (date: Date) => {
  return new Date(date).toLocaleDateString('pt-BR');
};

export const exportToExcel = (
  reportType: string,
  data: any,
  filters: { startDate: string; endDate: string }
) => {
  let worksheetData: any[] = [];
  let sheetName = 'Relatório';
  
  switch (reportType) {
    case 'orders':
      sheetName = 'Pedidos';
      worksheetData = [
        ['Número', 'Cliente', 'Data', 'Status', 'Subtotal', 'Desconto', 'Total'],
        ...(data as any[]).map(order => [
          order.number,
          order.clientName,
          formatDate(order.createdAt),
          order.status,
          order.subtotal,
          order.discount,
          order.total,
        ]),
      ];
      break;
      
    case 'quotes':
      sheetName = 'Orçamentos';
      worksheetData = [
        ['Número', 'Cliente', 'Data', 'Validade', 'Status', 'Subtotal', 'Desconto', 'Total'],
        ...(data as any[]).map(quote => [
          quote.number,
          quote.clientName,
          formatDate(quote.createdAt),
          formatDate(quote.validUntil),
          quote.status,
          quote.subtotal,
          quote.discount,
          quote.total,
        ]),
      ];
      break;
      
    case 'financial':
      sheetName = 'Financeiro';
      worksheetData = [
        ['Tipo', 'Categoria', 'Descrição', 'Data', 'Valor', 'Observações'],
        ...(data as any[]).map(t => [
          t.type === 'income' ? 'Receita' : 'Despesa',
          t.category,
          t.description,
          formatDate(t.date),
          t.amount,
          t.notes || '',
        ]),
      ];
      break;
      
    case 'profit':
      sheetName = 'Lucro';
      worksheetData = [
        ['Tipo', 'Valor'],
        ['Receitas', data.income],
        ['Despesas', data.expenses],
        ['Lucro', data.profit],
      ];
      break;
  }
  
  const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  
  // Auto-size columns
  const colWidths = worksheetData[0].map((_, colIndex) => ({
    wch: Math.max(
      ...worksheetData.map(row => String(row[colIndex] || '').length)
    ) + 2,
  }));
  worksheet['!cols'] = colWidths;
  
  XLSX.writeFile(workbook, `Relatorio_${reportType}_${new Date().toISOString().split('T')[0]}.xlsx`);
};
