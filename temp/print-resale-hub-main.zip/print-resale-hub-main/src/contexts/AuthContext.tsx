import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const INITIAL_USER: User = {
  id: '1',
  username: 'wesley.rocha',
  email: 'wesley@empresa.com',
  role: 'admin',
  createdAt: new Date(),
};

const INITIAL_CREDENTIALS = {
  username: 'wesley.rocha',
  password: 'as123123',
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('printshop_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    // Check stored users first
    const storedUsers = localStorage.getItem('printshop_users');
    const users = storedUsers ? JSON.parse(storedUsers) : [];
    
    // Check initial credentials
    if (username === INITIAL_CREDENTIALS.username && password === INITIAL_CREDENTIALS.password) {
      setUser(INITIAL_USER);
      localStorage.setItem('printshop_user', JSON.stringify(INITIAL_USER));
      return true;
    }

    // Check stored users
    const foundUser = users.find((u: any) => 
      u.username === username && u.password === password
    );

    if (foundUser) {
      const userWithoutPassword = { ...foundUser };
      delete userWithoutPassword.password;
      setUser(userWithoutPassword);
      localStorage.setItem('printshop_user', JSON.stringify(userWithoutPassword));
      return true;
    }

    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('printshop_user');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
