import { useState, useMemo, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useData } from '@/contexts/DataContext';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/ui/page-header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Trash2, ArrowLeft, Search, UserPlus } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { QuoteItem, DeliveryAddress } from '@/types';
import { fetchAddressByCep } from '@/lib/cep-service';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface OrderFormProps {
  type: 'order' | 'quote';
}

export default function OrderForm({ type }: OrderFormProps) {
  const navigate = useNavigate();
  const { id } = useParams();
  const { clients, products, addOrder, addQuote, orders, quotes, updateOrder, updateQuote } = useData();
  
  const isEditing = !!id;
  const existingItem = useMemo(() => {
    if (!id) return null;
    return type === 'order' 
      ? orders.find(o => o.id === id)
      : quotes.find(q => q.id === id);
  }, [id, type, orders, quotes]);

  const [clientId, setClientId] = useState(existingItem?.clientId || '');
  const [manualClientName, setManualClientName] = useState('');
  const [useManualClient, setUseManualClient] = useState(false);
  const [items, setItems] = useState<QuoteItem[]>(existingItem?.items || []);
  const [discount, setDiscount] = useState(existingItem?.discount || 0);
  const [notes, setNotes] = useState(existingItem?.notes || '');
  const [validDays, setValidDays] = useState(15);

  // Delivery address (only for orders)
  const existingOrder = type === 'order' ? existingItem as any : null;
  const [deliveryAddress, setDeliveryAddress] = useState<DeliveryAddress>({
    zipCode: existingOrder?.deliveryAddress?.zipCode || '',
    street: existingOrder?.deliveryAddress?.street || '',
    number: existingOrder?.deliveryAddress?.number || '',
    complement: existingOrder?.deliveryAddress?.complement || '',
    neighborhood: existingOrder?.deliveryAddress?.neighborhood || '',
    city: existingOrder?.deliveryAddress?.city || '',
    state: existingOrder?.deliveryAddress?.state || '',
  });
  const [isLoadingCep, setIsLoadingCep] = useState(false);

  // For adding new item
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [unitPrice, setUnitPrice] = useState(0);

  const selectedClient = useMemo(() => {
    return clients.find(c => c.id === clientId);
  }, [clients, clientId]);

  const selectedProduct = useMemo(() => {
    return products.find(p => p.id === selectedProductId);
  }, [products, selectedProductId]);

  const subtotal = useMemo(() => {
    return items.reduce((acc, item) => acc + item.total, 0);
  }, [items]);

  const total = useMemo(() => {
    return subtotal - discount;
  }, [subtotal, discount]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const handleProductSelect = (productId: string) => {
    setSelectedProductId(productId);
    const product = products.find(p => p.id === productId);
    if (product) {
      setUnitPrice(product.basePrice);
    }
  };

  const handleAddItem = () => {
    if (!selectedProduct || quantity <= 0) {
      toast({
        title: 'Erro',
        description: 'Selecione um produto e quantidade válida',
        variant: 'destructive',
      });
      return;
    }

    const newItem: QuoteItem = {
      id: Math.random().toString(36).substr(2, 9),
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      quantity,
      unitPrice,
      total: quantity * unitPrice,
    };

    setItems([...items, newItem]);
    setSelectedProductId('');
    setQuantity(1);
    setUnitPrice(0);
  };

  const handleRemoveItem = (itemId: string) => {
    setItems(items.filter(item => item.id !== itemId));
  };

  const handleCepSearch = async () => {
    if (!deliveryAddress.zipCode) return;
    
    setIsLoadingCep(true);
    const data = await fetchAddressByCep(deliveryAddress.zipCode);
    setIsLoadingCep(false);
    
    if (data) {
      setDeliveryAddress(prev => ({
        ...prev,
        street: data.logradouro || '',
        neighborhood: data.bairro || '',
        city: data.localidade || '',
        state: data.uf || '',
      }));
      toast({ title: 'Endereço encontrado!' });
    } else {
      toast({
        title: 'CEP não encontrado',
        description: 'Verifique o CEP e tente novamente',
        variant: 'destructive',
      });
    }
  };

  const handleCepChange = (value: string) => {
    // Format CEP as user types
    const cleanValue = value.replace(/\D/g, '');
    let formatted = cleanValue;
    if (cleanValue.length > 5) {
      formatted = `${cleanValue.slice(0, 5)}-${cleanValue.slice(5, 8)}`;
    }
    setDeliveryAddress(prev => ({ ...prev, zipCode: formatted }));
    
    // Auto-search when CEP is complete
    if (cleanValue.length === 8) {
      setTimeout(() => handleCepSearch(), 100);
    }
  };

  const getClientName = () => {
    if (useManualClient && manualClientName.trim()) {
      return manualClientName.trim();
    }
    return selectedClient?.name || 'Cliente não informado';
  };

  const handleSubmit = () => {
    const clientName = getClientName();
    
    const data = {
      clientId: useManualClient ? '' : clientId,
      clientName,
      items,
      subtotal,
      discount,
      total,
      notes,
    };

    if (type === 'order') {
      const orderData = {
        ...data,
        deliveryAddress: deliveryAddress.zipCode ? deliveryAddress : undefined,
      };
      
      if (isEditing) {
        updateOrder(id!, orderData);
        toast({ title: 'Pedido atualizado com sucesso' });
      } else {
        addOrder({ ...orderData, status: 'awaiting_payment', revenueAdded: false });
        toast({ title: 'Pedido criado com sucesso' });
      }
      navigate('/pedidos');
    } else {
      const validUntil = new Date();
      validUntil.setDate(validUntil.getDate() + validDays);
      
      if (isEditing) {
        updateQuote(id!, { ...data, validUntil });
        toast({ title: 'Orçamento atualizado com sucesso' });
      } else {
        addQuote({ ...data, status: 'pending', validUntil });
        toast({ title: 'Orçamento criado com sucesso' });
      }
      navigate('/pedidos');
    }
  };

  const title = type === 'order' 
    ? (isEditing ? 'Editar Pedido' : 'Novo Pedido')
    : (isEditing ? 'Editar Orçamento' : 'Novo Orçamento');

  return (
    <MainLayout>
      <PageHeader
        title={title}
        description={type === 'order' ? 'Crie ou edite um pedido' : 'Crie ou edite um orçamento'}
        actions={
          <Button variant="outline" onClick={() => navigate(-1)}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Client Selection */}
          <div className="form-section">
            <h3 className="font-display text-lg font-semibold mb-4">Cliente</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Button
                  type="button"
                  variant={!useManualClient ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setUseManualClient(false)}
                >
                  Selecionar cliente
                </Button>
                <Button
                  type="button"
                  variant={useManualClient ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setUseManualClient(true)}
                >
                  <UserPlus className="mr-2 h-4 w-4" />
                  Informar manualmente
                </Button>
              </div>

              {!useManualClient ? (
                <>
                  <div className="space-y-2">
                    <Label>Selecione o cliente</Label>
                    <Select value={clientId} onValueChange={setClientId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Escolha um cliente" />
                      </SelectTrigger>
                      <SelectContent>
                        {clients.map((client) => (
                          <SelectItem key={client.id} value={client.id}>
                            {client.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {selectedClient && (
                    <div className="rounded-lg bg-muted/50 p-4 text-sm">
                      <p><strong>Documento:</strong> {selectedClient.document || '-'}</p>
                      <p><strong>Telefone:</strong> {selectedClient.phone || '-'}</p>
                      <p><strong>E-mail:</strong> {selectedClient.email || '-'}</p>
                    </div>
                  )}
                </>
              ) : (
                <div className="space-y-2">
                  <Label>Nome do cliente</Label>
                  <Input
                    value={manualClientName}
                    onChange={(e) => setManualClientName(e.target.value)}
                    placeholder="Digite o nome do cliente"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Delivery Address - Only for orders */}
          {type === 'order' && (
            <Collapsible defaultOpen={!!existingOrder?.deliveryAddress}>
              <div className="form-section">
                <CollapsibleTrigger asChild>
                  <div className="flex items-center justify-between cursor-pointer">
                    <h3 className="font-display text-lg font-semibold">Endereço de Entrega</h3>
                    <Button variant="ghost" size="sm">Expandir</Button>
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label>CEP</Label>
                      <div className="flex gap-2">
                        <Input
                          value={deliveryAddress.zipCode}
                          onChange={(e) => handleCepChange(e.target.value)}
                          placeholder="00000-000"
                          maxLength={9}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={handleCepSearch}
                          disabled={isLoadingCep}
                        >
                          <Search className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Rua</Label>
                      <Input
                        value={deliveryAddress.street}
                        onChange={(e) => setDeliveryAddress(prev => ({ ...prev, street: e.target.value }))}
                        placeholder="Nome da rua"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Número</Label>
                      <Input
                        value={deliveryAddress.number}
                        onChange={(e) => setDeliveryAddress(prev => ({ ...prev, number: e.target.value }))}
                        placeholder="123"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Complemento</Label>
                      <Input
                        value={deliveryAddress.complement}
                        onChange={(e) => setDeliveryAddress(prev => ({ ...prev, complement: e.target.value }))}
                        placeholder="Apto, Sala, etc."
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Bairro</Label>
                      <Input
                        value={deliveryAddress.neighborhood}
                        onChange={(e) => setDeliveryAddress(prev => ({ ...prev, neighborhood: e.target.value }))}
                        placeholder="Bairro"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Cidade</Label>
                      <Input
                        value={deliveryAddress.city}
                        onChange={(e) => setDeliveryAddress(prev => ({ ...prev, city: e.target.value }))}
                        placeholder="Cidade"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Estado</Label>
                      <Input
                        value={deliveryAddress.state}
                        onChange={(e) => setDeliveryAddress(prev => ({ ...prev, state: e.target.value }))}
                        placeholder="UF"
                        maxLength={2}
                      />
                    </div>
                  </div>
                </CollapsibleContent>
              </div>
            </Collapsible>
          )}

          {/* Add Item */}
          <div className="form-section">
            <h3 className="font-display text-lg font-semibold mb-4">Adicionar Produto</h3>
            <div className="grid gap-4 sm:grid-cols-4">
              <div className="sm:col-span-2 space-y-2">
                <Label>Produto</Label>
                <Select value={selectedProductId} onValueChange={handleProductSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha um produto" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name} - {formatCurrency(product.basePrice)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Quantidade</Label>
                <Input
                  type="number"
                  min={1}
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                />
              </div>
              <div className="space-y-2">
                <Label>Preço Unit.</Label>
                <Input
                  type="number"
                  step="0.01"
                  min={0}
                  value={unitPrice}
                  onChange={(e) => setUnitPrice(parseFloat(e.target.value) || 0)}
                />
              </div>
            </div>
            <Button onClick={handleAddItem} className="mt-4">
              <Plus className="mr-2 h-4 w-4" />
              Adicionar Item
            </Button>
          </div>

          {/* Items Table */}
          <div className="form-section">
            <h3 className="font-display text-lg font-semibold mb-4">Itens</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Produto</TableHead>
                    <TableHead className="text-right">Qtd</TableHead>
                    <TableHead className="text-right">Preço Unit.</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                        Nenhum item adicionado
                      </TableCell>
                    </TableRow>
                  ) : (
                    items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.productName}</TableCell>
                        <TableCell className="text-right">{item.quantity}</TableCell>
                        <TableCell className="text-right">{formatCurrency(item.unitPrice)}</TableCell>
                        <TableCell className="text-right font-medium">{formatCurrency(item.total)}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => handleRemoveItem(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>

          {/* Notes */}
          <div className="form-section">
            <h3 className="font-display text-lg font-semibold mb-4">Observações</h3>
            <Textarea
              placeholder="Observações sobre o pedido..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
            />
          </div>
        </div>

        {/* Summary sidebar */}
        <div className="space-y-6">
          <div className="form-section sticky top-4">
            <h3 className="font-display text-lg font-semibold mb-4">Resumo</h3>
            
            <div className="space-y-4">
              {type === 'quote' && (
                <div className="space-y-2">
                  <Label>Validade (dias)</Label>
                  <Input
                    type="number"
                    min={1}
                    value={validDays}
                    onChange={(e) => setValidDays(parseInt(e.target.value) || 15)}
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label>Desconto (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  min={0}
                  value={discount}
                  onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                />
              </div>

              <div className="border-t border-border pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Desconto</span>
                  <span className="text-destructive">-{formatCurrency(discount)}</span>
                </div>
                <div className="flex justify-between text-lg font-bold border-t border-border pt-2">
                  <span>Total</span>
                  <span className="text-primary">{formatCurrency(total)}</span>
                </div>
              </div>

              <Button onClick={handleSubmit} className="w-full" size="lg">
                {isEditing ? 'Salvar Alterações' : (type === 'order' ? 'Criar Pedido' : 'Criar Orçamento')}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}