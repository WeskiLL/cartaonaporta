import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import logo from '@/assets/logo.png';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username.trim() || !password.trim()) {
      toast({
        title: 'Erro',
        description: 'Preencha todos os campos',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const success = await login(username.trim(), password);
      
      if (success) {
        toast({
          title: 'Bem-vindo!',
          description: 'Login realizado com sucesso',
        });
        navigate('/dashboard');
      } else {
        toast({
          title: 'Erro',
          description: 'Usuário ou senha incorretos',
          variant: 'destructive',
        });
      }
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao fazer login',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Left side - Form */}
      <div className="flex w-full flex-col justify-center px-4 py-12 sm:px-6 lg:w-1/2 lg:px-20 xl:px-24">
        <div className="mx-auto w-full max-w-sm">
          <div className="animate-slide-up">
            <div className="flex flex-col items-center gap-4 mb-10">
              <img src={logo} alt="Prime Print" className="h-24 w-auto" />
              <div className="text-center">
                <h1 className="font-display text-3xl font-bold text-foreground">Prime Print</h1>
                <p className="text-sm text-muted-foreground">Sistema de Gestão</p>
              </div>
            </div>

            <div className="mb-8 text-center">
              <h2 className="font-display text-xl font-semibold text-foreground">Entrar na sua conta</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Digite suas credenciais para acessar o sistema
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="username">Usuário</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="seu.usuario"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="h-11 border-border focus:border-primary focus:ring-primary"
                  autoComplete="username"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-11 pr-10 border-border focus:border-primary focus:ring-primary"
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="h-11 w-full font-medium"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  'Entrar'
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* Right side - Decorative */}
      <div className="hidden lg:flex lg:w-1/2 bg-foreground items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-transparent to-primary/20" />
        <div className="relative z-10 p-12 text-center">
          <div className="mb-8">
            <img src={logo} alt="Prime Print" className="h-32 w-auto mx-auto" />
          </div>
          <h2 className="font-display text-3xl font-bold text-background mb-4">
            Gerencie sua gráfica
          </h2>
          <p className="text-background/70 max-w-md mx-auto">
            Sistema completo para gestão de pedidos, orçamentos, clientes e financeiro da sua empresa de material impresso.
          </p>
        </div>
        
        {/* Decorative circles */}
        <div className="absolute -bottom-32 -right-32 h-64 w-64 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -top-32 -left-32 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
      </div>
    </div>
  );
}
