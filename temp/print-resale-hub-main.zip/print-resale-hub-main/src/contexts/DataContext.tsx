import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Client, Product, Quote, Order, Transaction, Mockup, Company } from '@/types';

interface DataContextType {
  // Clients
  clients: Client[];
  addClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  updateClient: (id: string, client: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  
  // Products
  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  
  // Quotes
  quotes: Quote[];
  addQuote: (quote: Omit<Quote, 'id' | 'number' | 'createdAt'>) => void;
  updateQuote: (id: string, quote: Partial<Quote>) => void;
  deleteQuote: (id: string) => void;
  convertQuoteToOrder: (quoteId: string) => void;
  
  // Orders
  orders: Order[];
  addOrder: (order: Omit<Order, 'id' | 'number' | 'createdAt'>) => void;
  updateOrder: (id: string, order: Partial<Order>) => void;
  deleteOrder: (id: string) => void;
  
  // Transactions
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  
  // Mockups
  mockups: Mockup[];
  addMockup: (mockup: Omit<Mockup, 'id' | 'createdAt'>) => void;
  deleteMockup: (id: string) => void;
  
  // Company
  company: Company | null;
  updateCompany: (company: Partial<Company>) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const generateId = () => Math.random().toString(36).substr(2, 9);

const generateNumber = (prefix: string, count: number) => 
  `${prefix}${String(count).padStart(5, '0')}`;

// Sample data
const sampleClients: Client[] = [
  {
    id: '1',
    name: 'João Silva Ltda',
    document: '12.345.678/0001-90',
    phone: '(11) 98765-4321',
    email: 'joao@empresa.com',
    address: 'Rua das Flores, 123',
    city: 'São Paulo',
    state: 'SP',
    zipCode: '01234-567',
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    name: 'Maria Santos ME',
    document: '98.765.432/0001-10',
    phone: '(11) 91234-5678',
    email: 'maria@santos.com',
    address: 'Av. Principal, 456',
    city: 'São Paulo',
    state: 'SP',
    zipCode: '04567-890',
    createdAt: new Date('2024-02-20'),
  },
];

const sampleProducts: Product[] = [
  {
    id: '1',
    name: 'Cartão de Visita',
    description: 'Cartão de visita 9x5cm, papel couchê 300g',
    basePrice: 80,
    cost: 25,
    category: 'Cartões',
    createdAt: new Date('2024-01-01'),
  },
  {
    id: '2',
    name: 'Flyer A5',
    description: 'Flyer A5, papel couchê 150g, 4x4 cores',
    basePrice: 150,
    cost: 50,
    category: 'Impressos',
    createdAt: new Date('2024-01-01'),
  },
  {
    id: '3',
    name: 'Banner Lona',
    description: 'Banner em lona 440g, acabamento ilhós',
    basePrice: 45,
    cost: 15,
    category: 'Banners',
    createdAt: new Date('2024-01-01'),
  },
];

const sampleOrders: Order[] = [
  {
    id: '1',
    number: 'PED00001',
    clientId: '1',
    clientName: 'João Silva Ltda',
    items: [
      { id: '1', productId: '1', productName: 'Cartão de Visita', quantity: 1000, unitPrice: 0.08, total: 80 },
      { id: '2', productId: '2', productName: 'Flyer A5', quantity: 500, unitPrice: 0.30, total: 150 },
    ],
    subtotal: 230,
    discount: 0,
    total: 230,
    status: 'delivered',
    createdAt: new Date('2024-12-01'),
    completedAt: new Date('2024-12-05'),
    revenueAdded: true,
  },
  {
    id: '2',
    number: 'PED00002',
    clientId: '2',
    clientName: 'Maria Santos ME',
    items: [
      { id: '1', productId: '3', productName: 'Banner Lona', quantity: 5, unitPrice: 45, total: 225 },
    ],
    subtotal: 225,
    discount: 25,
    total: 200,
    status: 'production',
    createdAt: new Date('2024-12-06'),
    revenueAdded: true,
  },
];

const sampleTransactions: Transaction[] = [
  {
    id: '1',
    type: 'income',
    category: 'Vendas',
    description: 'Pedido PED00001 - João Silva',
    amount: 230,
    date: new Date('2024-12-05'),
    orderId: '1',
  },
  {
    id: '2',
    type: 'expense',
    category: 'Materiais',
    description: 'Compra de papel couchê',
    amount: 500,
    date: new Date('2024-12-03'),
  },
  {
    id: '3',
    type: 'expense',
    category: 'Operacional',
    description: 'Conta de luz',
    amount: 350,
    date: new Date('2024-12-01'),
  },
];

export function DataProvider({ children }: { children: ReactNode }) {
  const [clients, setClients] = useState<Client[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [mockups, setMockups] = useState<Mockup[]>([]);
  const [company, setCompany] = useState<Company | null>(null);

  // Load data from localStorage
  useEffect(() => {
    const loadData = (key: string, defaultData: any[]) => {
      const stored = localStorage.getItem(`printshop_${key}`);
      return stored ? JSON.parse(stored) : defaultData;
    };

    setClients(loadData('clients', sampleClients));
    setProducts(loadData('products', sampleProducts));
    setQuotes(loadData('quotes', []));
    setOrders(loadData('orders', sampleOrders));
    setTransactions(loadData('transactions', sampleTransactions));
    setMockups(loadData('mockups', []));
    
    const storedCompany = localStorage.getItem('printshop_company');
    if (storedCompany) {
      setCompany(JSON.parse(storedCompany));
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    if (clients.length) localStorage.setItem('printshop_clients', JSON.stringify(clients));
  }, [clients]);

  useEffect(() => {
    if (products.length) localStorage.setItem('printshop_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('printshop_quotes', JSON.stringify(quotes));
  }, [quotes]);

  useEffect(() => {
    if (orders.length) localStorage.setItem('printshop_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    if (transactions.length) localStorage.setItem('printshop_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('printshop_mockups', JSON.stringify(mockups));
  }, [mockups]);

  useEffect(() => {
    if (company) localStorage.setItem('printshop_company', JSON.stringify(company));
  }, [company]);

  // Client methods
  const addClient = (client: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = { ...client, id: generateId(), createdAt: new Date() };
    setClients(prev => [...prev, newClient]);
  };

  const updateClient = (id: string, client: Partial<Client>) => {
    setClients(prev => prev.map(c => c.id === id ? { ...c, ...client } : c));
  };

  const deleteClient = (id: string) => {
    setClients(prev => prev.filter(c => c.id !== id));
  };

  // Product methods
  const addProduct = (product: Omit<Product, 'id' | 'createdAt'>) => {
    const newProduct: Product = { ...product, id: generateId(), createdAt: new Date() };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: string, product: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...product } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  // Quote methods
  const addQuote = (quote: Omit<Quote, 'id' | 'number' | 'createdAt'>) => {
    const newQuote: Quote = {
      ...quote,
      id: generateId(),
      number: generateNumber('ORC', quotes.length + 1),
      createdAt: new Date(),
    };
    setQuotes(prev => [...prev, newQuote]);
  };

  const updateQuote = (id: string, quote: Partial<Quote>) => {
    setQuotes(prev => prev.map(q => q.id === id ? { ...q, ...quote } : q));
  };

  const deleteQuote = (id: string) => {
    setQuotes(prev => prev.filter(q => q.id !== id));
  };

  const convertQuoteToOrder = (quoteId: string) => {
    const quote = quotes.find(q => q.id === quoteId);
    if (!quote) return;

    const newOrder: Order = {
      id: generateId(),
      number: generateNumber('PED', orders.length + 1),
      quoteId: quote.id,
      clientId: quote.clientId,
      clientName: quote.clientName,
      items: quote.items,
      subtotal: quote.subtotal,
      discount: quote.discount,
      total: quote.total,
      notes: quote.notes,
      status: 'awaiting_payment',
      createdAt: new Date(),
      revenueAdded: false,
    };

    setOrders(prev => [...prev, newOrder]);
    updateQuote(quoteId, { status: 'converted' });
  };

  // Order methods
  const addOrder = (order: Omit<Order, 'id' | 'number' | 'createdAt'>) => {
    const newOrder: Order = {
      ...order,
      id: generateId(),
      number: generateNumber('PED', orders.length + 1),
      createdAt: new Date(),
    };
    setOrders(prev => [...prev, newOrder]);
  };

  const updateOrder = (id: string, order: Partial<Order>) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, ...order } : o));
  };

  const deleteOrder = (id: string) => {
    setOrders(prev => prev.filter(o => o.id !== id));
  };

  // Transaction methods
  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = { ...transaction, id: generateId() };
    setTransactions(prev => [...prev, newTransaction]);
  };

  const updateTransaction = (id: string, transaction: Partial<Transaction>) => {
    setTransactions(prev => prev.map(t => t.id === id ? { ...t, ...transaction } : t));
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  // Mockup methods
  const addMockup = (mockup: Omit<Mockup, 'id' | 'createdAt'>) => {
    const newMockup: Mockup = { ...mockup, id: generateId(), createdAt: new Date() };
    setMockups(prev => [...prev, newMockup]);
  };

  const deleteMockup = (id: string) => {
    setMockups(prev => prev.filter(m => m.id !== id));
  };

  // Company methods
  const updateCompany = (companyData: Partial<Company>) => {
    setCompany(prev => {
      if (prev) {
        return { ...prev, ...companyData };
      }
      return { id: generateId(), ...companyData } as Company;
    });
  };

  return (
    <DataContext.Provider
      value={{
        clients,
        addClient,
        updateClient,
        deleteClient,
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        quotes,
        addQuote,
        updateQuote,
        deleteQuote,
        convertQuoteToOrder,
        orders,
        addOrder,
        updateOrder,
        deleteOrder,
        transactions,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        mockups,
        addMockup,
        deleteMockup,
        company,
        updateCompany,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
