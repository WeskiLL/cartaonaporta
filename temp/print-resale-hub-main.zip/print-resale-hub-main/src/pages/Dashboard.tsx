import { useMemo, useState, DragEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useData } from '@/contexts/DataContext';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/ui/page-header';
import { StatCard } from '@/components/ui/stat-card';
import { StatusBadge } from '@/components/ui/status-badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  ShoppingCart,
  DollarSign,
  TrendingDown,
  TrendingUp,
  FileText,
  Users,
  Package,
  Plus,
  ArrowRight,
  GripVertical,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Order } from '@/types';
import { toast } from '@/hooks/use-toast';

const ORDER_STATUSES: { key: Order['status']; label: string; color: string }[] = [
  { key: 'awaiting_payment', label: 'Aguardando Pagamento', color: 'hsl(38, 92%, 50%)' },
  { key: 'creating_art', label: 'Criando Arte', color: 'hsl(199, 89%, 48%)' },
  { key: 'production', label: 'Em Produção', color: 'hsl(28, 100%, 50%)' },
  { key: 'shipping', label: 'Em Transporte', color: 'hsl(142, 76%, 36%)' },
  { key: 'delivered', label: 'Entregue', color: 'hsl(142, 76%, 36%)' },
];

export default function Dashboard() {
  const { orders, quotes, transactions, clients, products, updateOrder, addTransaction, convertQuoteToOrder } = useData();
  const navigate = useNavigate();
  const [draggedOrder, setDraggedOrder] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);

  const stats = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const monthlyOrders = orders.filter(o => {
      const orderDate = new Date(o.createdAt);
      return orderDate.getMonth() === currentMonth && orderDate.getFullYear() === currentYear;
    });

    const monthlyTransactions = transactions.filter(t => {
      const transDate = new Date(t.date);
      return transDate.getMonth() === currentMonth && transDate.getFullYear() === currentYear;
    });

    const totalRevenue = monthlyTransactions
      .filter(t => t.type === 'income')
      .reduce((acc, t) => acc + t.amount, 0);

    const totalExpenses = monthlyTransactions
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => acc + t.amount, 0);

    const profit = totalRevenue - totalExpenses;

    return {
      ordersCount: monthlyOrders.length,
      totalRevenue,
      totalExpenses,
      profit,
    };
  }, [orders, transactions]);

  const chartData = useMemo(() => {
    const last6Months = [];
    const now = new Date();
    
    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthTransactions = transactions.filter(t => {
        const transDate = new Date(t.date);
        return transDate.getMonth() === date.getMonth() && transDate.getFullYear() === date.getFullYear();
      });

      const revenue = monthTransactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
      const expenses = monthTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);

      last6Months.push({
        month: date.toLocaleDateString('pt-BR', { month: 'short' }),
        receitas: revenue,
        despesas: expenses,
      });
    }
    
    return last6Months;
  }, [transactions]);

  const ordersByStatus = useMemo(() => {
    const grouped: Record<Order['status'], Order[]> = {
      awaiting_payment: [],
      creating_art: [],
      production: [],
      shipping: [],
      delivered: [],
    };
    
    orders.forEach(order => {
      if (grouped[order.status]) {
        grouped[order.status].push(order);
      }
    });
    
    return grouped;
  }, [orders]);

  const pendingQuotes = useMemo(() => {
    return quotes.filter(q => q.status === 'pending');
  }, [quotes]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const handleDragStart = (e: DragEvent, orderId: string) => {
    setDraggedOrder(orderId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: DragEvent, status: string) => {
    e.preventDefault();
    setDragOverColumn(status);
  };

  const handleDragLeave = () => {
    setDragOverColumn(null);
  };

  const handleDrop = (e: DragEvent, newStatus: Order['status']) => {
    e.preventDefault();
    setDragOverColumn(null);

    if (!draggedOrder) return;

    const order = orders.find(o => o.id === draggedOrder);
    if (!order || order.status === newStatus) {
      setDraggedOrder(null);
      return;
    }

    // Add revenue when moving to "creating_art" status
    if (newStatus === 'creating_art' && !order.revenueAdded) {
      addTransaction({
        type: 'income',
        category: 'Vendas',
        description: `Pedido ${order.number} - ${order.clientName}`,
        amount: order.total,
        date: new Date(),
        orderId: order.id,
      });
      updateOrder(order.id, { status: newStatus, revenueAdded: true });
      toast({
        title: 'Status atualizado',
        description: `Pedido movido para ${ORDER_STATUSES.find(s => s.key === newStatus)?.label}. Receita de ${formatCurrency(order.total)} adicionada.`,
      });
    } else {
      updateOrder(order.id, { status: newStatus });
      toast({
        title: 'Status atualizado',
        description: `Pedido movido para ${ORDER_STATUSES.find(s => s.key === newStatus)?.label}`,
      });
    }

    setDraggedOrder(null);
  };

  const handleConvertQuote = (quoteId: string) => {
    convertQuoteToOrder(quoteId);
    toast({ title: 'Orçamento convertido em pedido com sucesso' });
  };

  return (
    <MainLayout>
      <PageHeader
        title="Dashboard"
        description="Visão geral do seu negócio"
        actions={
          <Button asChild>
            <Link to="/pedidos/novo">
              <Plus className="mr-2 h-4 w-4" />
              Novo Pedido
            </Link>
          </Button>
        }
      />

      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <StatCard
          title="Pedidos do Mês"
          value={stats.ordersCount}
          icon={ShoppingCart}
          variant="primary"
        />
        <StatCard
          title="Total Faturado"
          value={formatCurrency(stats.totalRevenue)}
          icon={DollarSign}
          variant="success"
        />
        <StatCard
          title="Total de Despesas"
          value={formatCurrency(stats.totalExpenses)}
          icon={TrendingDown}
          variant="warning"
        />
        <StatCard
          title="Lucro Estimado"
          value={formatCurrency(stats.profit)}
          icon={TrendingUp}
          variant={stats.profit >= 0 ? 'success' : 'warning'}
        />
      </div>

      <Tabs defaultValue="kanban" className="animate-fade-in">
        <TabsList className="mb-6">
          <TabsTrigger value="kanban">Kanban de Pedidos</TabsTrigger>
          <TabsTrigger value="quotes">Orçamentos Pendentes ({pendingQuotes.length})</TabsTrigger>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
        </TabsList>

        <TabsContent value="kanban">
          {/* Kanban Board */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
            {ORDER_STATUSES.map((status) => (
              <div
                key={status.key}
                className={`kanban-column ${dragOverColumn === status.key ? 'drag-over' : ''}`}
                onDragOver={(e) => handleDragOver(e, status.key)}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, status.key)}
              >
                <div className="flex items-center justify-between mb-3 px-1">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: status.color }}
                    />
                    <h3 className="font-medium text-sm">{status.label}</h3>
                  </div>
                  <span className="text-xs text-muted-foreground bg-muted rounded-full px-2 py-0.5">
                    {ordersByStatus[status.key].length}
                  </span>
                </div>
                
                <div className="space-y-2 flex-1 overflow-y-auto max-h-[500px] scrollbar-thin">
                  {ordersByStatus[status.key].length === 0 ? (
                    <div className="text-center text-sm text-muted-foreground py-8">
                      Nenhum pedido
                    </div>
                  ) : (
                    ordersByStatus[status.key].map((order) => (
                      <div
                        key={order.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, order.id)}
                        className={`kanban-card ${draggedOrder === order.id ? 'dragging' : ''}`}
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <GripVertical className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{order.number}</p>
                            <p className="text-xs text-muted-foreground truncate">{order.clientName}</p>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-primary">
                            {formatCurrency(order.total)}
                          </span>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 text-xs"
                            onClick={() => navigate(`/pedidos/${order.id}/editar`)}
                          >
                            Ver
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="quotes">
          {/* Pending Quotes */}
          <div className="rounded-xl bg-card shadow-card overflow-hidden animate-slide-up">
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h3 className="font-display text-lg font-semibold">Orçamentos Aguardando Aprovação</h3>
              <Button variant="outline" size="sm" asChild>
                <Link to="/orcamentos/novo">
                  <Plus className="mr-2 h-4 w-4" />
                  Novo Orçamento
                </Link>
              </Button>
            </div>
            <div className="divide-y divide-border">
              {pendingQuotes.length === 0 ? (
                <div className="p-6 text-center text-muted-foreground">
                  Nenhum orçamento pendente
                </div>
              ) : (
                pendingQuotes.map((quote) => (
                  <div key={quote.id} className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-info/10">
                        <FileText className="h-5 w-5 text-info" />
                      </div>
                      <div>
                        <p className="font-medium">{quote.number}</p>
                        <p className="text-sm text-muted-foreground">{quote.clientName}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="font-medium">{formatCurrency(quote.total)}</p>
                        <p className="text-xs text-muted-foreground">
                          Válido até {new Date(quote.validUntil).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => handleConvertQuote(quote.id)}
                      >
                        Gerar Pedido
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="overview">
          {/* Charts and Quick Actions */}
          <div className="grid gap-6 lg:grid-cols-3 mb-8">
            {/* Revenue Chart */}
            <div className="lg:col-span-2 rounded-xl bg-card p-6 shadow-card animate-slide-up">
              <h3 className="font-display text-lg font-semibold mb-4">Receitas vs Despesas</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorReceitas" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(142, 76%, 36%)" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(142, 76%, 36%)" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorDespesas" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" tickFormatter={(value) => `R$${value}`} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => formatCurrency(value)}
                    />
                    <Area
                      type="monotone"
                      dataKey="receitas"
                      stroke="hsl(142, 76%, 36%)"
                      fillOpacity={1}
                      fill="url(#colorReceitas)"
                      name="Receitas"
                    />
                    <Area
                      type="monotone"
                      dataKey="despesas"
                      stroke="hsl(0, 84%, 60%)"
                      fillOpacity={1}
                      fill="url(#colorDespesas)"
                      name="Despesas"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="rounded-xl bg-card p-6 shadow-card animate-slide-up">
              <h3 className="font-display text-lg font-semibold mb-4">Atalhos Rápidos</h3>
              <div className="space-y-3">
                <Button asChild variant="outline" className="w-full justify-start h-12">
                  <Link to="/pedidos/novo">
                    <FileText className="mr-3 h-5 w-5 text-primary" />
                    Novo Pedido
                  </Link>
                </Button>
                <Button asChild variant="outline" className="w-full justify-start h-12">
                  <Link to="/orcamentos/novo">
                    <FileText className="mr-3 h-5 w-5 text-info" />
                    Novo Orçamento
                  </Link>
                </Button>
                <Button asChild variant="outline" className="w-full justify-start h-12">
                  <Link to="/clientes/novo">
                    <Users className="mr-3 h-5 w-5 text-success" />
                    Novo Cliente
                  </Link>
                </Button>
                <Button asChild variant="outline" className="w-full justify-start h-12">
                  <Link to="/produtos/novo">
                    <Package className="mr-3 h-5 w-5 text-warning" />
                    Novo Produto
                  </Link>
                </Button>
              </div>

              {/* Quick Stats */}
              <div className="mt-6 pt-6 border-t border-border">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 rounded-lg bg-muted/50">
                    <p className="text-2xl font-bold text-foreground">{clients.length}</p>
                    <p className="text-xs text-muted-foreground">Clientes</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/50">
                    <p className="text-2xl font-bold text-foreground">{products.length}</p>
                    <p className="text-xs text-muted-foreground">Produtos</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}
