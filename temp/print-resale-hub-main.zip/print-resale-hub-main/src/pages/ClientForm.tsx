import { useState, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useData } from '@/contexts/DataContext';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/ui/page-header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Save, AlertCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { maskPhone, maskCPFOrCNPJ, maskCEP, validateCPFOrCNPJ } from '@/lib/masks';
import { fetchAddressByCep } from '@/lib/cep-service';

export default function ClientForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { clients, addClient, updateClient } = useData();

  const existingClient = useMemo(() => {
    if (!id) return null;
    return clients.find(c => c.id === id);
  }, [id, clients]);

  const [formData, setFormData] = useState({
    name: existingClient?.name || '',
    document: existingClient?.document || '',
    phone: existingClient?.phone || '',
    email: existingClient?.email || '',
    address: existingClient?.address || '',
    city: existingClient?.city || '',
    state: existingClient?.state || '',
    zipCode: existingClient?.zipCode || '',
    notes: existingClient?.notes || '',
  });

  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [documentError, setDocumentError] = useState<string | null>(null);
  const isEditing = !!id;

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhoneChange = (value: string) => {
    handleChange('phone', maskPhone(value));
  };

  const handleDocumentChange = (value: string) => {
    const masked = maskCPFOrCNPJ(value);
    handleChange('document', masked);
    
    // Validate when complete
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length === 11 || cleaned.length === 14) {
      const validation = validateCPFOrCNPJ(masked);
      if (!validation.valid) {
        setDocumentError(validation.type === 'cpf' ? 'CPF inválido' : 'CNPJ inválido');
      } else {
        setDocumentError(null);
      }
    } else {
      setDocumentError(null);
    }
  };

  const handleCepChange = async (value: string) => {
    const masked = maskCEP(value);
    handleChange('zipCode', masked);
    
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length === 8) {
      setIsLoadingCep(true);
      const data = await fetchAddressByCep(cleaned);
      setIsLoadingCep(false);
      
      if (data) {
        setFormData(prev => ({
          ...prev,
          zipCode: masked,
          address: data.logradouro || prev.address,
          city: data.localidade || prev.city,
          state: data.uf || prev.state,
        }));
        toast({ title: 'Endereço encontrado!' });
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate document if provided
    if (formData.document) {
      const validation = validateCPFOrCNPJ(formData.document);
      if (!validation.valid && validation.type !== 'empty') {
        toast({
          title: 'Documento inválido',
          description: validation.type === 'cpf' ? 'O CPF informado é inválido' : 'O CNPJ informado é inválido',
          variant: 'destructive',
        });
        return;
      }
    }

    if (isEditing) {
      updateClient(id!, formData);
      toast({ title: 'Cliente atualizado com sucesso' });
    } else {
      addClient(formData);
      toast({ title: 'Cliente criado com sucesso' });
    }

    navigate('/clientes');
  };

  return (
    <MainLayout>
      <PageHeader
        title={isEditing ? 'Editar Cliente' : 'Novo Cliente'}
        description={isEditing ? 'Atualize os dados do cliente' : 'Cadastre um novo cliente'}
        actions={
          <Button variant="outline" onClick={() => navigate(-1)}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Button>
        }
      />

      <form onSubmit={handleSubmit} className="max-w-2xl">
        <div className="form-section space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="name">Nome / Razão Social</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="Nome completo ou razão social"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="document">CPF / CNPJ</Label>
              <div className="relative">
                <Input
                  id="document"
                  value={formData.document}
                  onChange={(e) => handleDocumentChange(e.target.value)}
                  placeholder="000.000.000-00"
                  maxLength={18}
                  className={documentError ? 'border-destructive pr-10' : ''}
                />
                {documentError && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <AlertCircle className="h-4 w-4 text-destructive" />
                  </div>
                )}
              </div>
              {documentError && (
                <p className="text-xs text-destructive">{documentError}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handlePhoneChange(e.target.value)}
                placeholder="(00) 00000-0000"
                maxLength={15}
              />
            </div>

            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="email@exemplo.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="zipCode">CEP</Label>
              <div className="flex gap-2">
                <Input
                  id="zipCode"
                  value={formData.zipCode}
                  onChange={(e) => handleCepChange(e.target.value)}
                  placeholder="00000-000"
                  maxLength={9}
                />
                {isLoadingCep && (
                  <div className="flex items-center">
                    <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full" />
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
                placeholder="Rua, número, complemento"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="city">Cidade</Label>
              <Input
                id="city"
                value={formData.city}
                onChange={(e) => handleChange('city', e.target.value)}
                placeholder="Cidade"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="state">UF</Label>
              <Input
                id="state"
                value={formData.state}
                onChange={(e) => handleChange('state', e.target.value.toUpperCase())}
                placeholder="SP"
                maxLength={2}
              />
            </div>

            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleChange('notes', e.target.value)}
                placeholder="Observações sobre o cliente..."
                rows={4}
              />
            </div>
          </div>

          <div className="flex gap-4 pt-4 border-t border-border">
            <Button type="submit" className="flex-1 sm:flex-none" disabled={!!documentError}>
              <Save className="mr-2 h-4 w-4" />
              {isEditing ? 'Salvar Alterações' : 'Cadastrar Cliente'}
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate(-1)}>
              Cancelar
            </Button>
          </div>
        </div>
      </form>
    </MainLayout>
  );
}