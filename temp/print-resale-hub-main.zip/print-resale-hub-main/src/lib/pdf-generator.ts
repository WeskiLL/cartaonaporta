import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Order, Quote, Company, DeliveryAddress } from '@/types';

// Brand colors - Orange palette (typed as tuples)
const BRAND_ORANGE: [number, number, number] = [234, 88, 12]; // hsl(25, 95%, 53%) -> RGB
const BRAND_DARK: [number, number, number] = [28, 25, 23]; // dark brown/black
const BRAND_LIGHT_GRAY: [number, number, number] = [245, 245, 244]; // light gray background

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

const formatDate = (date: Date) => {
  return new Date(date).toLocaleDateString('pt-BR');
};

const addCompanyHeader = async (doc: jsPDF, company: Company, startY: number = 15): Promise<number> => {
  let currentY = startY;
  
  // Add logo if exists
  if (company.logoUrl) {
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      
      await new Promise<void>((resolve, reject) => {
        img.onload = () => {
          const maxHeight = 20;
          const ratio = img.width / img.height;
          const width = maxHeight * ratio;
          doc.addImage(img, 'PNG', 14, currentY - 5, width, maxHeight);
          resolve();
        };
        img.onerror = () => resolve(); // Continue without logo if error
        img.src = company.logoUrl!;
      });
      
      currentY += 20;
    } catch (e) {
      // Continue without logo
    }
  }
  
  // Company name with brand color
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(BRAND_ORANGE[0], BRAND_ORANGE[1], BRAND_ORANGE[2]);
  doc.text(company.name, 14, currentY);
  currentY += 6;
  
  // Company details
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100);
  
  if (company.cnpj) {
    doc.text(`CNPJ: ${company.cnpj}`, 14, currentY);
    currentY += 4;
  }
  
  if (company.address) {
    let address = company.address;
    if (company.city) address += `, ${company.city}`;
    if (company.state) address += ` - ${company.state}`;
    if (company.zipCode) address += ` | CEP: ${company.zipCode}`;
    doc.text(address, 14, currentY);
    currentY += 4;
  }
  
  let contactLine = '';
  if (company.phone) contactLine += `Tel: ${company.phone}`;
  if (company.email) contactLine += (contactLine ? ' | ' : '') + company.email;
  if (contactLine) {
    doc.text(contactLine, 14, currentY);
    currentY += 4;
  }
  
  doc.setTextColor(0);
  
  // Line separator with brand color
  currentY += 4;
  doc.setDrawColor(BRAND_ORANGE[0], BRAND_ORANGE[1], BRAND_ORANGE[2]);
  doc.setLineWidth(0.5);
  doc.line(14, currentY, 196, currentY);
  
  return currentY + 8;
};

const formatDeliveryAddress = (address: DeliveryAddress): string => {
  let formatted = `${address.street}, ${address.number}`;
  if (address.complement) formatted += `, ${address.complement}`;
  formatted += ` - ${address.neighborhood}`;
  formatted += `\n${address.city} - ${address.state}, CEP: ${address.zipCode}`;
  return formatted;
};

export const generateOrderPDF = async (order: Order, company: Company) => {
  const doc = new jsPDF();
  
  let currentY = await addCompanyHeader(doc, company);
  
  // Title with brand color
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(BRAND_ORANGE[0], BRAND_ORANGE[1], BRAND_ORANGE[2]);
  doc.text(`PEDIDO ${order.number}`, 14, currentY);
  
  // Date
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
  doc.text(`Data: ${formatDate(order.createdAt)}`, 196, currentY, { align: 'right' });
  currentY += 10;
  
  // Client info
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
  doc.text('Cliente:', 14, currentY);
  doc.setFont('helvetica', 'normal');
  doc.text(order.clientName, 35, currentY);
  currentY += 8;
  
  // Delivery Address
  if (order.deliveryAddress) {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Endereço de Entrega:', 14, currentY);
    currentY += 5;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100);
    const addressLines = formatDeliveryAddress(order.deliveryAddress).split('\n');
    addressLines.forEach(line => {
      doc.text(line, 14, currentY);
      currentY += 4;
    });
    doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
    currentY += 4;
  }
  
  // Items table with brand colors
  autoTable(doc, {
    startY: currentY,
    head: [['Produto', 'Quantidade', 'Preço Unitário', 'Total']],
    body: order.items.map(item => [
      item.productName,
      item.quantity.toString(),
      formatCurrency(item.unitPrice),
      formatCurrency(item.total),
    ]),
    theme: 'striped',
    headStyles: {
      fillColor: BRAND_ORANGE,
      textColor: 255,
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: BRAND_LIGHT_GRAY,
    },
    styles: {
      fontSize: 9,
    },
    columnStyles: {
      0: { cellWidth: 80 },
      1: { halign: 'center', cellWidth: 30 },
      2: { halign: 'right', cellWidth: 40 },
      3: { halign: 'right', cellWidth: 35 },
    },
  });
  
  currentY = (doc as any).lastAutoTable.finalY + 10;
  
  // Totals
  const totalsX = 140;
  doc.setFontSize(10);
  doc.text('Subtotal:', totalsX, currentY);
  doc.text(formatCurrency(order.subtotal), 196, currentY, { align: 'right' });
  currentY += 5;
  
  if (order.discount > 0) {
    doc.text('Desconto:', totalsX, currentY);
    doc.setTextColor(255, 0, 0);
    doc.text(`-${formatCurrency(order.discount)}`, 196, currentY, { align: 'right' });
    doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
    currentY += 5;
  }
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('TOTAL:', totalsX, currentY);
  doc.setTextColor(BRAND_ORANGE[0], BRAND_ORANGE[1], BRAND_ORANGE[2]);
  doc.text(formatCurrency(order.total), 196, currentY, { align: 'right' });
  doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
  currentY += 15;
  
  // Notes
  if (order.notes) {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Observações:', 14, currentY);
    currentY += 5;
    doc.setFont('helvetica', 'normal');
    const splitNotes = doc.splitTextToSize(order.notes, 180);
    doc.text(splitNotes, 14, currentY);
  }
  
  doc.save(`Pedido_${order.number}.pdf`);
};

export const generateQuotePDF = async (quote: Quote, company: Company) => {
  const doc = new jsPDF();
  
  let currentY = await addCompanyHeader(doc, company);
  
  // Title with brand color
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(BRAND_ORANGE[0], BRAND_ORANGE[1], BRAND_ORANGE[2]);
  doc.text(`ORÇAMENTO ${quote.number}`, 14, currentY);
  
  // Date
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
  doc.text(`Data: ${formatDate(quote.createdAt)}`, 196, currentY, { align: 'right' });
  currentY += 6;
  doc.text(`Validade: ${formatDate(quote.validUntil)}`, 196, currentY, { align: 'right' });
  currentY += 10;
  
  // Client info
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
  doc.text('Cliente:', 14, currentY);
  doc.setFont('helvetica', 'normal');
  doc.text(quote.clientName, 35, currentY);
  currentY += 12;
  
  // Items table with brand colors
  autoTable(doc, {
    startY: currentY,
    head: [['Produto', 'Quantidade', 'Preço Unitário', 'Total']],
    body: quote.items.map(item => [
      item.productName,
      item.quantity.toString(),
      formatCurrency(item.unitPrice),
      formatCurrency(item.total),
    ]),
    theme: 'striped',
    headStyles: {
      fillColor: BRAND_ORANGE,
      textColor: 255,
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: BRAND_LIGHT_GRAY,
    },
    styles: {
      fontSize: 9,
    },
    columnStyles: {
      0: { cellWidth: 80 },
      1: { halign: 'center', cellWidth: 30 },
      2: { halign: 'right', cellWidth: 40 },
      3: { halign: 'right', cellWidth: 35 },
    },
  });
  
  currentY = (doc as any).lastAutoTable.finalY + 10;
  
  // Totals
  const totalsX = 140;
  doc.setFontSize(10);
  doc.text('Subtotal:', totalsX, currentY);
  doc.text(formatCurrency(quote.subtotal), 196, currentY, { align: 'right' });
  currentY += 5;
  
  if (quote.discount > 0) {
    doc.text('Desconto:', totalsX, currentY);
    doc.setTextColor(255, 0, 0);
    doc.text(`-${formatCurrency(quote.discount)}`, 196, currentY, { align: 'right' });
    doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
    currentY += 5;
  }
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('TOTAL:', totalsX, currentY);
  doc.setTextColor(BRAND_ORANGE[0], BRAND_ORANGE[1], BRAND_ORANGE[2]);
  doc.text(formatCurrency(quote.total), 196, currentY, { align: 'right' });
  doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
  currentY += 15;
  
  // Notes
  if (quote.notes) {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Observações:', 14, currentY);
    currentY += 5;
    doc.setFont('helvetica', 'normal');
    const splitNotes = doc.splitTextToSize(quote.notes, 180);
    doc.text(splitNotes, 14, currentY);
  }
  
  doc.save(`Orcamento_${quote.number}.pdf`);
};

export const generateReportPDF = async (
  reportType: string,
  data: any,
  company: Company | null,
  filters: { startDate: string; endDate: string }
) => {
  const doc = new jsPDF();
  
  let currentY = 15;
  
  if (company) {
    currentY = await addCompanyHeader(doc, company);
  }
  
  // Report title with brand color
  const titles: Record<string, string> = {
    orders: 'RELATÓRIO DE PEDIDOS',
    quotes: 'RELATÓRIO DE ORÇAMENTOS',
    financial: 'RELATÓRIO FINANCEIRO',
    profit: 'RELATÓRIO DE LUCRO',
  };
  
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(BRAND_ORANGE[0], BRAND_ORANGE[1], BRAND_ORANGE[2]);
  doc.text(titles[reportType] || 'RELATÓRIO', 14, currentY);
  currentY += 6;
  
  // Period
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(BRAND_DARK[0], BRAND_DARK[1], BRAND_DARK[2]);
  let period = 'Período: ';
  if (filters.startDate || filters.endDate) {
    period += filters.startDate ? formatDate(new Date(filters.startDate)) : 'Início';
    period += ' até ';
    period += filters.endDate ? formatDate(new Date(filters.endDate)) : 'Hoje';
  } else {
    period += 'Todos os registros';
  }
  doc.text(period, 14, currentY);
  currentY += 10;
  
  if (reportType === 'orders' && Array.isArray(data)) {
    autoTable(doc, {
      startY: currentY,
      head: [['Número', 'Cliente', 'Data', 'Status', 'Total']],
      body: data.map((order: any) => [
        order.number,
        order.clientName,
        formatDate(order.createdAt),
        order.status,
        formatCurrency(order.total),
      ]),
      theme: 'striped',
      headStyles: { fillColor: BRAND_ORANGE },
      alternateRowStyles: { fillColor: BRAND_LIGHT_GRAY },
      styles: { fontSize: 8 },
    });
    
    currentY = (doc as any).lastAutoTable.finalY + 10;
    const total = data.reduce((acc: number, o: any) => acc + o.total, 0);
    doc.setFont('helvetica', 'bold');
    doc.text(`Total: ${formatCurrency(total)}`, 14, currentY);
  }
  
  if (reportType === 'quotes' && Array.isArray(data)) {
    autoTable(doc, {
      startY: currentY,
      head: [['Número', 'Cliente', 'Data', 'Validade', 'Status', 'Total']],
      body: data.map((quote: any) => [
        quote.number,
        quote.clientName,
        formatDate(quote.createdAt),
        formatDate(quote.validUntil),
        quote.status,
        formatCurrency(quote.total),
      ]),
      theme: 'striped',
      headStyles: { fillColor: BRAND_ORANGE },
      alternateRowStyles: { fillColor: BRAND_LIGHT_GRAY },
      styles: { fontSize: 8 },
    });
  }
  
  if (reportType === 'financial' && Array.isArray(data)) {
    autoTable(doc, {
      startY: currentY,
      head: [['Tipo', 'Categoria', 'Descrição', 'Data', 'Valor']],
      body: data.map((t: any) => [
        t.type === 'income' ? 'Receita' : 'Despesa',
        t.category,
        t.description,
        formatDate(t.date),
        formatCurrency(t.amount),
      ]),
      theme: 'striped',
      headStyles: { fillColor: BRAND_ORANGE },
      alternateRowStyles: { fillColor: BRAND_LIGHT_GRAY },
      styles: { fontSize: 8 },
    });
  }
  
  if (reportType === 'profit' && data.profit !== undefined) {
    doc.setFontSize(12);
    doc.text(`Receitas: ${formatCurrency(data.income)}`, 14, currentY);
    currentY += 7;
    doc.text(`Despesas: ${formatCurrency(data.expenses)}`, 14, currentY);
    currentY += 7;
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(BRAND_ORANGE[0], BRAND_ORANGE[1], BRAND_ORANGE[2]);
    doc.text(`Lucro: ${formatCurrency(data.profit)}`, 14, currentY);
  }
  
  doc.save(`Relatorio_${reportType}_${new Date().toISOString().split('T')[0]}.pdf`);
};