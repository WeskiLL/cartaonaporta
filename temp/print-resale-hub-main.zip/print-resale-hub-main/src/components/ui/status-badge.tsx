import { cn } from '@/lib/utils';
import { OrderStatus, QuoteStatus } from '@/types';

interface StatusBadgeProps {
  status: OrderStatus | QuoteStatus;
  className?: string;
}

const statusConfig: Record<string, { label: string; className: string }> = {
  // Order statuses
  awaiting_payment: { label: 'Aguardando Pagamento', className: 'badge-pending' },
  creating_art: { label: 'Criando Arte', className: 'badge-creating-art' },
  production: { label: 'Em Produção', className: 'badge-production' },
  shipping: { label: 'Em Transporte', className: 'badge-shipped' },
  delivered: { label: 'Entregue', className: 'badge-completed' },
  // Quote statuses
  pending: { label: 'Pendente', className: 'badge-pending' },
  approved: { label: 'Aprovado', className: 'badge-completed' },
  rejected: { label: 'Rejeitado', className: 'badge-cancelled' },
  converted: { label: 'Convertido', className: 'badge-completed' },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status] || { label: status, className: 'badge-pending' };
  
  return (
    <span className={cn('badge-status', config.className, className)}>
      {config.label}
    </span>
  );
}
