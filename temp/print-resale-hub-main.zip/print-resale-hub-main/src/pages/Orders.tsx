import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useData } from '@/contexts/DataContext';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/ui/page-header';
import { StatusBadge } from '@/components/ui/status-badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Plus,
  Search,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  FileDown,
  ArrowUpDown,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { generateOrderPDF, generateQuotePDF } from '@/lib/pdf-generator';
import { Order, Quote } from '@/types';
import { PDFPreviewDialog } from '@/components/PDFPreviewDialog';

export default function Orders() {
  const { orders, quotes, deleteOrder, deleteQuote, convertQuoteToOrder, updateOrder, company } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; type: 'order' | 'quote'; id: string }>({
    open: false,
    type: 'order',
    id: '',
  });
  const [previewDialog, setPreviewDialog] = useState<{
    open: boolean;
    type: 'order' | 'quote';
    data: Order | Quote | null;
  }>({
    open: false,
    type: 'order',
    data: null,
  });

  const filteredOrders = useMemo(() => {
    return orders.filter(order =>
      order.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.clientName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [orders, searchTerm]);

  const filteredQuotes = useMemo(() => {
    return quotes.filter(quote =>
      quote.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quote.clientName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [quotes, searchTerm]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const handleDelete = () => {
    if (deleteDialog.type === 'order') {
      deleteOrder(deleteDialog.id);
      toast({ title: 'Pedido excluído com sucesso' });
    } else {
      deleteQuote(deleteDialog.id);
      toast({ title: 'Orçamento excluído com sucesso' });
    }
    setDeleteDialog({ open: false, type: 'order', id: '' });
  };

  const handleConvertToOrder = (quoteId: string) => {
    convertQuoteToOrder(quoteId);
    toast({ title: 'Orçamento convertido em pedido com sucesso' });
  };

  const handleUpdateStatus = (orderId: string, status: Order['status']) => {
    updateOrder(orderId, { status });
    toast({ title: `Status atualizado para: ${status}` });
  };

  const handlePreviewPDF = (item: Order | Quote, type: 'order' | 'quote') => {
    if (!company) {
      toast({
        title: 'Dados da empresa não configurados',
        description: 'Configure os dados da sua empresa antes de gerar o PDF',
        variant: 'destructive',
      });
      return;
    }
    setPreviewDialog({ open: true, type, data: item });
  };

  const handleConfirmPDF = async () => {
    if (!previewDialog.data || !company) return;
    
    if (previewDialog.type === 'order') {
      await generateOrderPDF(previewDialog.data as Order, company);
    } else {
      await generateQuotePDF(previewDialog.data as Quote, company);
    }
    toast({ title: 'PDF gerado com sucesso' });
    setPreviewDialog({ open: false, type: 'order', data: null });
  };

  return (
    <MainLayout>
      <PageHeader
        title="Pedidos e Orçamentos"
        description="Gerencie seus pedidos e orçamentos"
        actions={
          <div className="flex gap-2">
            <Button asChild variant="outline">
              <Link to="/orcamentos/novo">
                <Plus className="mr-2 h-4 w-4" />
                Novo Orçamento
              </Link>
            </Button>
            <Button asChild>
              <Link to="/pedidos/novo">
                <Plus className="mr-2 h-4 w-4" />
                Novo Pedido
              </Link>
            </Button>
          </div>
        }
      />

      <div className="mb-6">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar por número ou cliente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Tabs defaultValue="orders" className="animate-fade-in">
        <TabsList className="mb-6">
          <TabsTrigger value="orders">Pedidos ({orders.length})</TabsTrigger>
          <TabsTrigger value="quotes">Orçamentos ({quotes.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="orders">
          <div className="data-table">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Número</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="w-[70px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                      Nenhum pedido encontrado
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredOrders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">{order.number}</TableCell>
                      <TableCell>{order.clientName}</TableCell>
                      <TableCell>{formatDate(order.createdAt)}</TableCell>
                      <TableCell>
                        <StatusBadge status={order.status} />
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {formatCurrency(order.total)}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                              <Link to={`/pedidos/${order.id}`}>
                                <Eye className="mr-2 h-4 w-4" />
                                Visualizar
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link to={`/pedidos/${order.id}/editar`}>
                                <Edit className="mr-2 h-4 w-4" />
                                Editar
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handlePreviewPDF(order, 'order')}>
                              <FileDown className="mr-2 h-4 w-4" />
                              Gerar PDF
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleUpdateStatus(order.id, 'creating_art')}
                              disabled={order.status === 'creating_art'}
                            >
                              <ArrowUpDown className="mr-2 h-4 w-4" />
                              Criando Arte
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleUpdateStatus(order.id, 'production')}
                              disabled={order.status === 'production'}
                            >
                              <ArrowUpDown className="mr-2 h-4 w-4" />
                              Em Produção
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleUpdateStatus(order.id, 'shipping')}
                              disabled={order.status === 'shipping'}
                            >
                              <ArrowUpDown className="mr-2 h-4 w-4" />
                              Em Transporte
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleUpdateStatus(order.id, 'delivered')}
                              disabled={order.status === 'delivered'}
                            >
                              <ArrowUpDown className="mr-2 h-4 w-4" />
                              Entregue
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => setDeleteDialog({ open: true, type: 'order', id: order.id })}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="quotes">
          <div className="data-table">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Número</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Validade</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="w-[70px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredQuotes.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                      Nenhum orçamento encontrado
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredQuotes.map((quote) => (
                    <TableRow key={quote.id}>
                      <TableCell className="font-medium">{quote.number}</TableCell>
                      <TableCell>{quote.clientName}</TableCell>
                      <TableCell>{formatDate(quote.createdAt)}</TableCell>
                      <TableCell>{formatDate(quote.validUntil)}</TableCell>
                      <TableCell>
                        <StatusBadge status={quote.status} />
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {formatCurrency(quote.total)}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                              <Link to={`/orcamentos/${quote.id}`}>
                                <Eye className="mr-2 h-4 w-4" />
                                Visualizar
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handlePreviewPDF(quote, 'quote')}>
                              <FileDown className="mr-2 h-4 w-4" />
                              Gerar PDF
                            </DropdownMenuItem>
                            {quote.status === 'pending' && (
                              <DropdownMenuItem onClick={() => handleConvertToOrder(quote.id)}>
                                <ArrowUpDown className="mr-2 h-4 w-4" />
                                Converter em Pedido
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => setDeleteDialog({ open: true, type: 'quote', id: quote.id })}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      <AlertDialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog(prev => ({ ...prev, open }))}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este {deleteDialog.type === 'order' ? 'pedido' : 'orçamento'}?
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {previewDialog.data && company && (
        <PDFPreviewDialog
          open={previewDialog.open}
          onOpenChange={(open) => setPreviewDialog(prev => ({ ...prev, open }))}
          type={previewDialog.type}
          data={previewDialog.data}
          company={company}
          onConfirm={handleConfirmPDF}
        />
      )}
    </MainLayout>
  );
}