import { useState, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useData } from '@/contexts/DataContext';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/ui/page-header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Save } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function ProductForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { products, addProduct, updateProduct } = useData();

  const existingProduct = useMemo(() => {
    if (!id) return null;
    return products.find(p => p.id === id);
  }, [id, products]);

  const [formData, setFormData] = useState({
    name: existingProduct?.name || '',
    description: existingProduct?.description || '',
    basePrice: existingProduct?.basePrice || 0,
    cost: existingProduct?.cost || 0,
    category: existingProduct?.category || '',
    imageUrl: existingProduct?.imageUrl || '',
  });

  const isEditing = !!id;

  const handleChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const productData = {
      ...formData,
      cost: formData.cost || undefined,
    };

    if (isEditing) {
      updateProduct(id!, productData);
      toast({ title: 'Produto atualizado com sucesso' });
    } else {
      addProduct(productData);
      toast({ title: 'Produto criado com sucesso' });
    }

    navigate('/produtos');
  };

  return (
    <MainLayout>
      <PageHeader
        title={isEditing ? 'Editar Produto' : 'Novo Produto'}
        description={isEditing ? 'Atualize os dados do produto' : 'Cadastre um novo produto'}
        actions={
          <Button variant="outline" onClick={() => navigate(-1)}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Button>
        }
      />

      <form onSubmit={handleSubmit} className="max-w-2xl">
        <div className="form-section space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="name">Nome do Produto</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="Ex: Cartão de Visita"
              />
            </div>

            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Descrição detalhada do produto..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Categoria</Label>
              <Input
                id="category"
                value={formData.category}
                onChange={(e) => handleChange('category', e.target.value)}
                placeholder="Ex: Cartões, Impressos, Banners"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="basePrice">Preço Base (R$)</Label>
              <Input
                id="basePrice"
                type="number"
                step="0.01"
                min="0"
                value={formData.basePrice}
                onChange={(e) => handleChange('basePrice', parseFloat(e.target.value) || 0)}
                placeholder="0,00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cost">Custo (R$)</Label>
              <Input
                id="cost"
                type="number"
                step="0.01"
                min="0"
                value={formData.cost}
                onChange={(e) => handleChange('cost', parseFloat(e.target.value) || 0)}
                placeholder="0,00"
              />
              <p className="text-xs text-muted-foreground">Opcional - usado para cálculo de lucro</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="imageUrl">URL da Imagem</Label>
              <Input
                id="imageUrl"
                value={formData.imageUrl}
                onChange={(e) => handleChange('imageUrl', e.target.value)}
                placeholder="https://..."
              />
            </div>

            {formData.imageUrl && (
              <div className="sm:col-span-2">
                <Label>Preview da Imagem</Label>
                <div className="mt-2 aspect-video max-w-xs rounded-lg bg-muted overflow-hidden">
                  <img
                    src={formData.imageUrl}
                    alt="Preview"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-4 pt-4 border-t border-border">
            <Button type="submit" className="flex-1 sm:flex-none">
              <Save className="mr-2 h-4 w-4" />
              {isEditing ? 'Salvar Alterações' : 'Cadastrar Produto'}
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate(-1)}>
              Cancelar
            </Button>
          </div>
        </div>
      </form>
    </MainLayout>
  );
}
