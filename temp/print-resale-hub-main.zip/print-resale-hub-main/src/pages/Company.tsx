import { useState, useEffect } from 'react';
import { useData } from '@/contexts/DataContext';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/ui/page-header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Save, Building2, AlertCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { maskPhone, maskCNPJ, maskCEP, validateCNPJ } from '@/lib/masks';
import { fetchAddressByCep } from '@/lib/cep-service';

export default function Company() {
  const { company, updateCompany } = useData();

  const [formData, setFormData] = useState({
    name: '',
    cnpj: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    phone: '',
    email: '',
    website: '',
    logoUrl: '',
  });

  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [cnpjError, setCnpjError] = useState<string | null>(null);

  useEffect(() => {
    if (company) {
      setFormData({
        name: company.name || '',
        cnpj: company.cnpj || '',
        address: company.address || '',
        city: company.city || '',
        state: company.state || '',
        zipCode: company.zipCode || '',
        phone: company.phone || '',
        email: company.email || '',
        website: company.website || '',
        logoUrl: company.logoUrl || '',
      });
    }
  }, [company]);

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhoneChange = (value: string) => {
    handleChange('phone', maskPhone(value));
  };

  const handleCnpjChange = (value: string) => {
    const masked = maskCNPJ(value);
    handleChange('cnpj', masked);
    
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length === 14) {
      if (!validateCNPJ(cleaned)) {
        setCnpjError('CNPJ inválido');
      } else {
        setCnpjError(null);
      }
    } else {
      setCnpjError(null);
    }
  };

  const handleCepChange = async (value: string) => {
    const masked = maskCEP(value);
    handleChange('zipCode', masked);
    
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length === 8) {
      setIsLoadingCep(true);
      const data = await fetchAddressByCep(cleaned);
      setIsLoadingCep(false);
      
      if (data) {
        setFormData(prev => ({
          ...prev,
          zipCode: masked,
          address: data.logradouro || prev.address,
          city: data.localidade || prev.city,
          state: data.uf || prev.state,
        }));
        toast({ title: 'Endereço encontrado!' });
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast({
        title: 'Erro',
        description: 'O nome da empresa é obrigatório',
        variant: 'destructive',
      });
      return;
    }

    // Validate CNPJ if provided
    if (formData.cnpj) {
      const cleaned = formData.cnpj.replace(/\D/g, '');
      if (cleaned.length === 14 && !validateCNPJ(cleaned)) {
        toast({
          title: 'CNPJ inválido',
          description: 'O CNPJ informado não é válido',
          variant: 'destructive',
        });
        return;
      }
    }

    updateCompany(formData);
    toast({ title: 'Dados da empresa atualizados com sucesso' });
  };

  return (
    <MainLayout>
      <PageHeader
        title="Minha Empresa"
        description="Configure os dados da sua empresa para os PDFs"
      />

      <form onSubmit={handleSubmit} className="max-w-2xl">
        <div className="form-section space-y-6">
          {/* Logo Section */}
          <div className="flex items-center gap-6 pb-6 border-b border-border">
            <div className="flex h-24 w-24 items-center justify-center rounded-xl bg-muted overflow-hidden">
              {formData.logoUrl ? (
                <img
                  src={formData.logoUrl}
                  alt="Logo"
                  className="w-full h-full object-contain"
                />
              ) : (
                <Building2 className="h-10 w-10 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <Label htmlFor="logoUpload">Upload da Logo</Label>
                <Input
                  id="logoUpload"
                  type="file"
                  accept="image/*"
                  className="mt-2"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onloadend = () => {
                        handleChange('logoUrl', reader.result as string);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />
              </div>
              <div>
                <Label htmlFor="logoUrl">Ou insira a URL da logo</Label>
                <Input
                  id="logoUrl"
                  value={formData.logoUrl?.startsWith('data:') ? '' : formData.logoUrl}
                  onChange={(e) => handleChange('logoUrl', e.target.value)}
                  placeholder="https://exemplo.com/logo.png"
                  className="mt-2"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                A logo aparecerá nos PDFs de pedidos e orçamentos
              </p>
            </div>
          </div>

          {/* Company Info */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="name">Nome da Empresa *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="Razão social ou nome fantasia"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cnpj">CNPJ</Label>
              <div className="relative">
                <Input
                  id="cnpj"
                  value={formData.cnpj}
                  onChange={(e) => handleCnpjChange(e.target.value)}
                  placeholder="00.000.000/0000-00"
                  maxLength={18}
                  className={cnpjError ? 'border-destructive pr-10' : ''}
                />
                {cnpjError && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <AlertCircle className="h-4 w-4 text-destructive" />
                  </div>
                )}
              </div>
              {cnpjError && (
                <p className="text-xs text-destructive">{cnpjError}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handlePhoneChange(e.target.value)}
                placeholder="(00) 00000-0000"
                maxLength={15}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="contato@empresa.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                value={formData.website}
                onChange={(e) => handleChange('website', e.target.value)}
                placeholder="www.empresa.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="zipCode">CEP</Label>
              <div className="flex gap-2">
                <Input
                  id="zipCode"
                  value={formData.zipCode}
                  onChange={(e) => handleCepChange(e.target.value)}
                  placeholder="00000-000"
                  maxLength={9}
                />
                {isLoadingCep && (
                  <div className="flex items-center">
                    <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full" />
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
                placeholder="Rua, número, complemento"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="city">Cidade</Label>
              <Input
                id="city"
                value={formData.city}
                onChange={(e) => handleChange('city', e.target.value)}
                placeholder="Cidade"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="state">UF</Label>
              <Input
                id="state"
                value={formData.state}
                onChange={(e) => handleChange('state', e.target.value.toUpperCase())}
                placeholder="SP"
                maxLength={2}
              />
            </div>
          </div>

          <div className="flex gap-4 pt-4 border-t border-border">
            <Button type="submit" disabled={!!cnpjError}>
              <Save className="mr-2 h-4 w-4" />
              Salvar Alterações
            </Button>
          </div>
        </div>
      </form>

      {/* Preview */}
      {formData.name && (
        <div className="mt-8 max-w-2xl">
          <h3 className="font-display text-lg font-semibold mb-4">Preview do Cabeçalho do PDF</h3>
          <div className="form-section">
            <div className="flex items-start gap-4">
              {formData.logoUrl && (
                <img
                  src={formData.logoUrl}
                  alt="Logo"
                  className="h-16 w-16 object-contain"
                />
              )}
              <div>
                <h4 className="font-display text-lg font-bold text-primary">{formData.name}</h4>
                {formData.cnpj && <p className="text-sm text-muted-foreground">CNPJ: {formData.cnpj}</p>}
                {formData.address && (
                  <p className="text-sm text-muted-foreground">
                    {formData.address}
                    {formData.city && `, ${formData.city}`}
                    {formData.state && ` - ${formData.state}`}
                    {formData.zipCode && ` CEP: ${formData.zipCode}`}
                  </p>
                )}
                <p className="text-sm text-muted-foreground">
                  {formData.phone && `Tel: ${formData.phone}`}
                  {formData.phone && formData.email && ' | '}
                  {formData.email && formData.email}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </MainLayout>
  );
}