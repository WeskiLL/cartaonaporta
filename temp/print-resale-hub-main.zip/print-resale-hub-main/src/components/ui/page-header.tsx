import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: ReactNode;
  className?: string;
}

export function PageHeader({ title, description, actions, className }: PageHeaderProps) {
  return (
    <div className={cn('page-header flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between', className)}>
      <div className="animate-fade-in">
        <h1 className="page-title">{title}</h1>
        {description && <p className="page-description">{description}</p>}
      </div>
      {actions && (
        <div className="flex items-center gap-2 animate-fade-in">{actions}</div>
      )}
    </div>
  );
}
