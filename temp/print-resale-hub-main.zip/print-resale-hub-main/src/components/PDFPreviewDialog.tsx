import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Download, X, MessageCircle, Mail } from 'lucide-react';
import { Order, Quote, Company, DeliveryAddress } from '@/types';
import { maskPhone } from '@/lib/masks';

interface PDFPreviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: 'order' | 'quote';
  data: Order | Quote;
  company: Company;
  onConfirm: () => void;
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

const formatDate = (date: Date) => {
  return new Date(date).toLocaleDateString('pt-BR');
};

const formatDeliveryAddress = (address: DeliveryAddress): string => {
  let formatted = `${address.street}, ${address.number}`;
  if (address.complement) formatted += `, ${address.complement}`;
  formatted += ` - ${address.neighborhood}`;
  formatted += `, ${address.city} - ${address.state}, CEP: ${address.zipCode}`;
  return formatted;
};

export function PDFPreviewDialog({
  open,
  onOpenChange,
  type,
  data,
  company,
  onConfirm,
}: PDFPreviewDialogProps) {
  const isOrder = type === 'order';
  const order = data as Order;
  const quote = data as Quote;

  const [showShareOptions, setShowShareOptions] = useState(false);
  const [whatsappNumber, setWhatsappNumber] = useState('');

  const generateWhatsAppMessage = () => {
    const docType = isOrder ? 'Pedido' : 'Orçamento';
    const number = data.number;
    let message = `*${docType} ${number}*\n`;
    message += `*${company.name}*\n\n`;
    message += `Cliente: ${data.clientName}\n`;
    message += `Data: ${formatDate(data.createdAt)}\n\n`;
    message += `*Itens:*\n`;
    data.items.forEach(item => {
      message += `• ${item.productName} - ${item.quantity}x ${formatCurrency(item.unitPrice)} = ${formatCurrency(item.total)}\n`;
    });
    message += `\n*Total: ${formatCurrency(data.total)}*\n`;
    if (data.notes) {
      message += `\nObs: ${data.notes}`;
    }
    return encodeURIComponent(message);
  };

  const handleWhatsAppShare = () => {
    const cleanNumber = whatsappNumber.replace(/\D/g, '');
    if (cleanNumber.length < 10) {
      return;
    }
    const message = generateWhatsAppMessage();
    const url = `https://wa.me/55${cleanNumber}?text=${message}`;
    window.open(url, '_blank');
  };

  const handleEmailShare = () => {
    const docType = isOrder ? 'Pedido' : 'Orçamento';
    const subject = encodeURIComponent(`${docType} ${data.number} - ${company.name}`);
    let body = `${docType} ${data.number}\n`;
    body += `${company.name}\n\n`;
    body += `Cliente: ${data.clientName}\n`;
    body += `Data: ${formatDate(data.createdAt)}\n\n`;
    body += `Itens:\n`;
    data.items.forEach(item => {
      body += `• ${item.productName} - ${item.quantity}x ${formatCurrency(item.unitPrice)} = ${formatCurrency(item.total)}\n`;
    });
    body += `\nTotal: ${formatCurrency(data.total)}\n`;
    if (data.notes) {
      body += `\nObs: ${data.notes}`;
    }
    const mailtoUrl = `mailto:?subject=${subject}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoUrl;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Preview do PDF - {isOrder ? `Pedido ${order.number}` : `Orçamento ${quote.number}`}</DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[50vh] pr-4">
          <div className="space-y-6 py-4">
            {/* Company Header */}
            <div className="border-b border-primary pb-4">
              <div className="flex items-start gap-4">
                {company.logoUrl && (
                  <img
                    src={company.logoUrl}
                    alt="Logo"
                    className="h-16 w-16 object-contain"
                  />
                )}
                <div>
                  <h3 className="text-lg font-bold text-primary">{company.name}</h3>
                  {company.cnpj && <p className="text-sm text-muted-foreground">CNPJ: {company.cnpj}</p>}
                  {company.address && (
                    <p className="text-sm text-muted-foreground">
                      {company.address}
                      {company.city && `, ${company.city}`}
                      {company.state && ` - ${company.state}`}
                      {company.zipCode && ` | CEP: ${company.zipCode}`}
                    </p>
                  )}
                  <p className="text-sm text-muted-foreground">
                    {company.phone && `Tel: ${company.phone}`}
                    {company.phone && company.email && ' | '}
                    {company.email && company.email}
                  </p>
                </div>
              </div>
            </div>

            {/* Document Info */}
            <div className="flex justify-between items-start">
              <div>
                <h4 className="text-lg font-bold text-primary">
                  {isOrder ? `PEDIDO ${order.number}` : `ORÇAMENTO ${quote.number}`}
                </h4>
                <p className="text-sm text-muted-foreground">Data: {formatDate(data.createdAt)}</p>
                {!isOrder && (
                  <p className="text-sm text-muted-foreground">Validade: {formatDate(quote.validUntil)}</p>
                )}
              </div>
            </div>

            {/* Client Info */}
            <div>
              <p className="font-semibold">Cliente: <span className="font-normal">{data.clientName}</span></p>
              {isOrder && order.deliveryAddress?.zipCode && (
                <div className="mt-2">
                  <p className="font-semibold text-sm">Endereço de Entrega:</p>
                  <p className="text-sm text-muted-foreground">
                    {formatDeliveryAddress(order.deliveryAddress)}
                  </p>
                </div>
              )}
            </div>

            {/* Items Table */}
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-primary text-primary-foreground">
                  <tr>
                    <th className="text-left p-2">Produto</th>
                    <th className="text-center p-2">Qtd</th>
                    <th className="text-right p-2">Preço Unit.</th>
                    <th className="text-right p-2">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((item, index) => (
                    <tr key={item.id} className={index % 2 === 0 ? 'bg-muted/30' : ''}>
                      <td className="p-2">{item.productName}</td>
                      <td className="text-center p-2">{item.quantity}</td>
                      <td className="text-right p-2">{formatCurrency(item.unitPrice)}</td>
                      <td className="text-right p-2">{formatCurrency(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="text-right space-y-1">
              <p className="text-sm">Subtotal: {formatCurrency(data.subtotal)}</p>
              {data.discount > 0 && (
                <p className="text-sm text-destructive">Desconto: -{formatCurrency(data.discount)}</p>
              )}
              <p className="text-lg font-bold text-primary">TOTAL: {formatCurrency(data.total)}</p>
            </div>

            {/* Notes */}
            {data.notes && (
              <div className="border-t pt-4">
                <p className="font-semibold text-sm">Observações:</p>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{data.notes}</p>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Share Options */}
        {showShareOptions && (
          <div className="border-t pt-4 space-y-4">
            <div className="space-y-2">
              <Label>Enviar por WhatsApp</Label>
              <div className="flex gap-2">
                <Input
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(maskPhone(e.target.value))}
                  placeholder="(00) 00000-0000"
                  maxLength={15}
                />
                <Button 
                  onClick={handleWhatsAppShare}
                  disabled={whatsappNumber.replace(/\D/g, '').length < 10}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <MessageCircle className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <Button variant="outline" className="w-full" onClick={handleEmailShare}>
              <Mail className="mr-2 h-4 w-4" />
              Enviar por E-mail
            </Button>
          </div>
        )}

        <DialogFooter className="gap-2 flex-wrap">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            <X className="mr-2 h-4 w-4" />
            Cancelar
          </Button>
          <Button 
            variant="outline" 
            onClick={() => setShowShareOptions(!showShareOptions)}
          >
            <MessageCircle className="mr-2 h-4 w-4" />
            Compartilhar
          </Button>
          <Button onClick={onConfirm}>
            <Download className="mr-2 h-4 w-4" />
            Gerar PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}