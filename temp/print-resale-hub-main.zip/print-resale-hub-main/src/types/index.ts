export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'financeiro' | 'vendedor';
  createdAt: Date;
}

export interface Client {
  id: string;
  name: string;
  document: string; // CPF or CNPJ
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  notes?: string;
  createdAt: Date;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  cost?: number;
  category: string;
  imageUrl?: string;
  createdAt: Date;
}

export interface QuoteItem {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Quote {
  id: string;
  number: string;
  clientId: string;
  clientName: string;
  items: QuoteItem[];
  subtotal: number;
  discount: number;
  total: number;
  notes?: string;
  status: 'pending' | 'approved' | 'rejected' | 'converted';
  createdAt: Date;
  validUntil: Date;
}

export interface DeliveryAddress {
  zipCode: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
}

export interface Order {
  id: string;
  number: string;
  quoteId?: string;
  clientId: string;
  clientName: string;
  items: QuoteItem[];
  subtotal: number;
  discount: number;
  total: number;
  notes?: string;
  status: 'awaiting_payment' | 'creating_art' | 'production' | 'shipping' | 'delivered';
  createdAt: Date;
  completedAt?: Date;
  revenueAdded?: boolean;
  deliveryAddress?: DeliveryAddress;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  category: string;
  description: string;
  amount: number;
  date: Date;
  notes?: string;
  orderId?: string;
}

export interface Mockup {
  id: string;
  name: string;
  category: string;
  imageUrl: string;
  createdAt: Date;
}

export interface Company {
  id: string;
  name: string;
  cnpj: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  email: string;
  website?: string;
  logoUrl?: string;
}

export type OrderStatus = Order['status'];
export type QuoteStatus = Quote['status'];
export type TransactionType = Transaction['type'];
export type UserRole = User['role'];
